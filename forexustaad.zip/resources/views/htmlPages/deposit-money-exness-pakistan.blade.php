@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>How to Deposit and Withdraw money in exness from Pakistan</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                                <p>
                                    In this Post I will teach you how to money deposit in your exness account from Pakistan via Excard.
                                </p>
                                
                                <p>
                                    Like You want invest in PKR and also withdraw in Pak rupess then no problem it’s very easy
                                </p>
                                
                                <p>
                                    you may invest in exness via easy paisa , Omni or any Bank account, you just need to watch video and learn
                                </p>
                                
                                <p>
                                    how to invest dollar in Exness.com . If you don’t Know about Forex then you must watch this Video link below
                                </p>
                                
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/exness-to-Pakistani-rupes.jpg')}}" class="img-fluid">
                                </div>
                                
                                <h4>
                                    What is Forex Trading in Urdu
                                </h4>
                                
                                <p>
                                    Dosto Ajj mein app ko exness me paisy invest and withdraw karny ky bary me bataoo ga , ky kisy app exness me apny Pakistani rupess deposit kar sakty ho and kisy aon rupess ko withdraw kar sakty ho , ye bohat asan kam hai app Easy paisa , Omni and kisi be Bank account sy ye kam kar sakty ho , mein app ki help karo ga es kam me app just Video dikho and learn more ….. Thank you
                                </p>
                               
                                <h5>
                                    For more information feel free to contact us.
                                </h5>
                                <br>
                                <ul>
                                    <li>Contact: Raheel Nawaz
                                    </li>
                                    <li>24/7 Live Support</li>
                                    <li>E-mail: Raheeljutt@gmail.com</li>
                                    <li>Skype: Raheel6542380</li>
                                    <li>Cell #: +92-345-6542380</li>
                                </ul>
                                <h5 class="text-center">
                                  General rules for depositing and withdrawing funds
                                </h5>
                                <br>
                                <ol>
                                  <li>The term “instant” shall be understood to mean that a transaction is carried out within a few seconds without manual processing by financial department specialists.</li>
                                  <li>Funds may only be withdrawn to clients’ personal accounts in order to ensure financial security and prevent money laundering.</li>
                                  <li>The company will not accept direct payments or payments to third parties; clients are given all necessary information in their personal area when completing a transaction.</li>
                                  <li>Deposits and withdrawals may be made 24 hours a day, 7 days a week. If a deposit or withdrawal is not carried out instantly, it will be completed within 24 hours.</li>
                                  <li>The company shall not be liable for delays in processing deposits and withdrawals if such delays are caused by the payment system.</li>
                                  <li>Internal transfers between accounts of the same type are performed instantly. Internal transfers are not available to clients who use credit cards to fund their trading accounts.</li>
                                  <li>If a client funds his/her trading account using multiple payment systems or multiple wallets within the same payment system, funds must be withdrawn in proportion to the amounts deposited.</li>
                                  <li>The company retains the right to change the processing time for deposits and withdrawals without notifying clients in advance</li>
                                  <li>e company may place limits on the payment systems available to clients from certain countries.</li>
                                </ol>
                                <br>
                                
                            </div>
                        </div>

                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>

@include('inc.footer')