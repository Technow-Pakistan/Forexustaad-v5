@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                   <div class="family">
                            <div>
                                <h4>Fundamental Analysis about US Presidential Election 2016</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                    <li><div id="shareLink"></div></li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/trump.jpg')}}" class="img-fluid">
                                </div>
                                <br>
                                <h5 class="text-center">Fundamental Analysis for Forex Trading, A Free Video for Newbie in Urdu / Hindi
                                </h5>
                                
                                <p>
                                    Finally today is US Election Day, the day to decide the result of the battle which was started on the media almost a year back. Media has already made the mind of people that Mrs. Clinton is going to be the 1st female president of USA. I expect the same but I believe that the margin of victory will be very narrow. Regardless of what the result comes out it’ll leave an effect on dollar and currencies. if Hillary wins , I expect that the dollar will turn bullish and can move 200 points at least and other currencies against dollar will get weak, especially JPY, CHF and EUR, while on the other side, if Trump wins dollar will weaken because it will leave a bad impact on US economy. Most affected will be JPY as it will get very strong along with CHF and EURO. This is our point of view according to our own Fundamental analysis and may differ from what your point of views and your analysis.
                                </p>
                                
                                <h5 class="text-center">
                                    Fundamental Analysis about US Presidential Election 2016 Urdu | hindi
                                </h5>
                                <div class="text-center">
                                    <iframe width="576" height="315" src="https://www.youtube.com/embed/XQpDeblNeuI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                <br>
                                <h5 class="text-center">
                                    Fundamental Analysis about US Election 2016 Urdu | Hindi Part 2
                                </h5>
                                <div class="text-center">
                                    <iframe width="576" height="315" src="https://www.youtube.com/embed/nGWmqlJntmo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                
                                
                            </div>
                        </div>  
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>



@include('inc.footer')