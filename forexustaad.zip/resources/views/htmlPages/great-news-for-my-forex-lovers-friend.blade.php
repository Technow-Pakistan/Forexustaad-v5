@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                                        <div class="pb-2">
                                            <h1>Great news for my Forex lovers Friends</h1>
                                        </div>
                                        <div class="post_representor">
                                            <ul class="">
                                                <li><i class="far fa-user"></i> Raheel Nawaz</li>
                                                <li><i class="far fa-clock"></i> September 2, 2015</li>
                                            </ul>
                                            <div id="shareLink" align="right"></div>
                                        </div>
                                        
                                        <div class="pt-4">
                                            <h4>
                                                Salam-Alikom
                                            </h4>
                                            
                                            <p>
                                                Meiny sab dosto ky liy Free webinar rakha hai, but ye free hai nai ye jo log mery sy training ly rahy hai aos ki class hai but aon logo ky tawon sy sab ko 1 webinar free dia jay ga , es webinar sara koch pro hai yani jo aon logo ko sikhaoo ga aos me sye he koch app logo ko free bata dia jay ga , es webinar mein hum log Basic Japanese Candlestick Patterns ky bary me baat kary gy , Candlestick bohat kamal ki chez hai , es sy app log bohat achy pips earn kar sakty hai, Webinar free ho just 1 din ky liy 🙂
                                            </p>
                                            
                                            <p>
                                                I have one more Good news for my VIPs members area friends , Jin jin logo ny mery reffras sy exness ko join kya hai aur wo log trading kar rahy hai aon sab ko 1 Free e-Book be do ga , but pleas note ye Book aon logo ky liy hai jo trading kar rahy hai NOT for every one , Learn free Forex Trading and earn 1000$ par month
                                            </p>
                                            
                                            <p>
                                                Sab log webinar join be kary and apny friends ky sath share be kary , taky zyda sy zyda Log es free webinar sy faida hasil kar saky
                                            </p>
                                            
                                            <div class="text-center">
                                                <img src="{{URL::to('/public/assets/assets/img/blog-post/Candlesticks.jpg')}}" class="w-100">
                                            </div>
                                            
                                            <p>
                                                I have a Plan Free webinar about Basic Japanese Candlestick Patterns on 30 March at 10-PM also share with your friends ,
                                            </p>
                                            
                                            <h4 class="text-center">
                                                What is Candlestick Strategy in urdu/Hindi
                                            </h4>
                                        </div>
                                        <div class="text-center">
                                            <a href="what-is-candlestick-strategy-in-urduhindi-part-1.html"><button class="p-3 text-center btn btn-primary">Join Our Webinars</button></a>
                                        </div>
                                        

                                        
                                    </div>

                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')