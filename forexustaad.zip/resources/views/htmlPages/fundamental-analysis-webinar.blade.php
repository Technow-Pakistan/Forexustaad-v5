@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                @php
                    if(Session::has('error')){ 
                        $error =Session::get('error');
                    }
                @endphp
                @isset($error)
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="alert alert-danger">{{$error}}</div>
                        @php Session::pull('error') @endphp
                    </div>
                @endisset
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                        <div class="family">
                            <div>
                                <h4>Fundamental Analysis,A Free webinar for Newbie in urdu/hindi</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                               <h3>
                                   Salam o alikom my Friends ,
                               </h3>
                               
                               <p>
                                   I have an other Good news for all my ForexUstaad members, I have organize a Free webinar about Fundamental Analysis for only Newbie, if you are a new Forex trader then this is very good chance to learn about Fundamental Analysis.
                               </p>
                               
                               <div class="text-center">
                                   <img src="{{URL::to('/public/assets/assets/img/blog-post/Fundamental-Analysis.png')}}" class="img-fluid">
                               </div> 
                               
                               <h3>
                                   In this webinar I will teach you about ………
                               </h3>
                               
                               <div>
                                   <ul>
                                   <li>What is Fundamental Trading ?</li>
                                   <li>How much News Types  ?</li>
                                   <li>What is forexfactory.com</li>
                                   <li>News Impacts ?</li>
                                   <li>Calendar in Forex >?</li>
                                   <li>What is Sessions ?</li>
                                   <li>What is Fundamental Analysis ?</li>
                                   <li>Best time for trading ?</li>
                               </ul>
                               </div>
                               
                               <p>
                                   For watch this webinar you need to just click on below link :
                               </p>
                               <h3 class="text-center">
                                   Fundamental Analysis for Forex Trading, A Free Video for Newbie in urdu/hindi
                               </h3>
                               
                               <p>
                                   Pleas note : This is a sponsor webinar so pleas says Thanks to my sponsor and also pray for him.You must Leave a message in Comment Box for our sponsor
                               </p>
                               
                               <div>
                                       <iframe src="https://player.vimeo.com/video/126562298" frameborder="0" allowfullscreen="allowfullscreen" name="fitvid0" width="100%" height="380"></iframe>
                                   </div>
                               
                            </div>
                        </div>

                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')