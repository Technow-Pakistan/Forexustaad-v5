@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
    
                <div class="family">
                            <div>
                                <h4>Pinbar candlestick strategies in urdu</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                               Hay Friends,
                               
                               <p>
                                   Today I share with you a Pinbar strategy. It is very useful strategy and I have earned number of pips by using this strategy, So I Decided to share with you Pinbar strategy because this strategy base on candlesticks. Pinbar strategy is only one part of Candlestick strategies. There are number of others strategies on base of candlesticks like Hammer , Doji , Hanging man and Shooting star single candle strategy and other strategies combination of two or more candlesticks pattern like Bullish Engulfing Pattern, Bearish Engulfing Pattern, Dark Cloud Cover Pattern , Piercing Line Pattern, Harami Pattern, Morning and Evening Star pattern etc. I will share with you InshAllah one by one …..
                               </p>
                               
                               <h4>
                                   <strong>
                                       I also show you result of my last topic , in my last topic I share with you ForexUstaad-pro indicator. So I earn 500 plus point from ForexUstaad-pro indicator, you also try this one
                                   </strong>
                               </h4>
                               <h2>
                                   <strong>What is Pinbar :</strong>
                               </h2>
                               <h4>
                                   Please watch this video and comments about it 
                               </h4>
                               <br>
                               <div>
                                   <iframe frameborder="0" width="100%" height="370" src="https://www.dailymotion.com/embed/video/x23uw26" allowfullscreen allow="autoplay"></iframe>
                               </div>
                               
                            </div>
                        </div>                    


                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')