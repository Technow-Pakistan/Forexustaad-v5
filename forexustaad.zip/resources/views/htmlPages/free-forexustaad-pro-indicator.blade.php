@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>Free indicator for Forex | Forexustaad-pro indicator</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                    <li><div id="shareLink"></div></li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                               <h3>
                                   Hey Friends,
                               </h3>
                               
                               <p>
                                   Today 14 August, 2014 is independence day of Pakistan. As I promised with you that I teach you free about forex trading. I’m very happy to start my website on 14 August, 2014 So today I share with you a very useful  indicator, its name is Forexustaad-pro.
                               </p>
                               
                               <p>
                                   If you are new trader and loss your money in forex trading, So friends don’t worry about your losses because Now you are on right place
                               </p>
                               <p>
                                   
                               Forexustaad-pro is very helpful indicator in forex trading. because I personally use it for the last 2 years and its result  is amazing for me and other traders who use it. I already promised with you that I teach you 100% free education regarding forex trading and also provide them 100% free Indicator and other material about forex trading so you can download this indicator free here. I show you in video how to use it and how can attach with terminal, (Metatrader 4 and Metatrader 5) . if you want to start using Forexustaad-pro  today. first of all you must practise on Demo account at least  three weeks then you start to use it on real account I hope you will start earning  200 to 300 pips with little practise easily
                               </p>
                               
                               <div>
                                   <h4 class="text-center">
                                   Please watch this video and comments about it 
                               </h4>
                               </div>
                               
                               <div>
                                   <iframe frameborder="0" width="100%" height="370" src="https://www.dailymotion.com/embed/video/x23ln8h" allowfullscreen allow="autoplay"></iframe>
                               </div>
                               
                            </div>
                        </div>


                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>



@include('inc.footer')