@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>What is Forex Trading in Urdu (webinar)</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                    <li><div id="shareLink"></div></li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/Forexustaad.jpg')}}" class="img-fluid">
                                </div>
                                <br><br>
                                <h4>
                                    <strong>
                                        Salam o alikom Dear friends
                                    </strong>
                                </h4>
                                <br>
                                <p>
                                    <strong>
                                    Today webinar is Totally about Forex trading and it’s full with information about Forex trading, in this video you find your all question Like
                                </strong>
                                </p>
                                
                                <div>
                                    <ol>
                                    <li><strong>What is Forex ?</strong></li>
                                    <ul>
                                        <li>Foreign Exchange Market which is commonly known as “Forex” it’s also called FX Market and Currency Market, is a global financial market where different Currencies of the world are traded in pairs</li>
                                    </ul><br>
                                    <li><strong>Size of Forex market ?</strong></li>
                                    <ul>
                                        <li>Watch Video by click on like button</li>
                                    </ul><br>
                                    <li><strong>Where is forex Located ?</strong></li>
                                    <ul>
                                        <li>Watch Video by click on like button</li>
                                    </ul><br>
                                    <li><strong>What is Traded in Forex ?</strong></li>
                                    <li><strong>What is Currencies ?</strong></li>
                                    <li><strong>What is Currencies Pair</strong></li>
                                    <li><strong>What is forex trading plan</strong></li>
                                    <li><strong>What is forex trading Strategy</strong></li>
                                    <li><strong>What is Candlestick Strategy</strong></li>
                                    <li><strong>What is Fundamental Trading Strategy</strong></li>
                                </ol>
                                </div>
                                
                                <p>
                                    Pleas Note Video is Locked , it’s very easy to unlock video just click on any one like button to unlock the video
                                </p>
                                <br><br>
                                <div>
                                    <iframe width="100%" height="315" src="https://www.youtube.com/embed/X9JClP-XMyc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                
                            </div>
                        </div>


                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>

@include('inc.footer')

