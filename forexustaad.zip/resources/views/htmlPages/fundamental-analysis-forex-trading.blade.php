@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    <div class="family">
                            <div>
                                <h4>Fundamental Analysis for Forex Trading, A Free Video for Newbie in urdu/hindi</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="far fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="far fa-clock"></i> September 2, 2015</li>
                                </ul>
                                <div id="shareLink" align="right"></div>
                            </div>
                            <div class="pt-4">
                                <p>
                                    Dear Friends 99% traders fail and they loss all there funds in Forex trading , I know you also worry about your future in Forex Market , Yo want to answer ?? why your Stop loss hit early and why you loss your all money in Forex Market, Today try to Find your all answer in our Fundamental Analysis  webinar, In this Video (webinar) I will teach you how to do Fundamental Analysis for your Forex Trading and stop losing money in Forex Market.
                                </p>
                                
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/fundamental-analysis.jpg')}}">
                                </div>
                                
                                <p>
                                    I will teach you which time is best for entering in Forex market and which or where you stop Trading and exit safely from Forex market, Basically that all Fundamental Analysis.
                                </p>
                                
                                <h4>
                                    What is Candlestick Strategy in urdu/Hindi
                                </h4>
                                <br>
                                <h3 class="text-center">
                                    What is Fundamental Analysis ?
                                </h3>
                                
                                <p>
                                    This is type of market analysis which examination of the underlying forces that affect the well being of the economy, industry groups, and companies. As with most Fundamental analysis, the goal is to derive a forecast and profit from future price movements, Basically if we look at Economic Analysis, Industry Analysis, Company Analysis, GDP, Inflation, Government Policy, Economic Policy, RBI Policy, Financial Analysis and Growth of industry that all call Fundamental analysis in Forex Trading.
                                </p>
                                
                                <h4>In this video (webinar) I will teach you about ………</h4>
                                <br>
                                <div>
                                    <ul>
                                    <li>What is Fundamental analysis  and how to do (basics only)?</li>
                                    <li>How much Type of News and how news affect on market ?</li>
                                    <li>What is forexfactory.com and how to use for Forex Trading ?</li>
                                    <li>What is imports of Calendar in Forex Trading ?</li>
                                    <li>What is Sessions ?</li>
                                    <li>which is Best time for trading ?</li>
                                </ul>
                                </div>
                                <br>
                               <p>
                                   <strong>Pleas note :</strong>  This is a sponsor webinar so pleas says Thanks to my sponsor and also pray for him.You must Leave a message in Comment Box for our sponsor
                               </p>
                              
                               
                                   <div>
                                       <iframe src="https://player.vimeo.com/video/126562298" frameborder="0" allowfullscreen="allowfullscreen" name="fitvid0" width="100%" height="380"></iframe>
                                   </div>
                               
                               

                            </div>
                        </div>
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')