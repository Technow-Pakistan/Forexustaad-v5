@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>Forex Trading using Moving Average Strategy in urdu/Hindi</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                                <p>
                                    Friends Today Mr.Hamid Teach you what is “Moving Average” and how can word this strategy to help use for earn some pips in Forex Trading, fist is very imported question is what is Moving Average Strategy
                                </p>
                                
                                <h2>
                                    <strong>What is Moving Average ?</strong>
                                </h2>
                                
                                <p>
                                    A simple moving average is the simple type of moving Lines, These line we draw on our trading charts for help to analysis about next Market move that’s why we called moving average. Basically, a simple moving average is a type of indicator who indicate us about next market move.Pleas find blow the Moving Average example image , you see  in this image 3 lines
                                </p>
                                
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/Forex-ustad.jpg')}}" class="img-fluid">
                                </div>
                                
                                <h2>
                                    <strong>Moving Average Types ?</strong>
                                </h2>
                                <br>
                                <p>
                                    There are 3 types of moving averages available to meet differing market analysis needs.
                                </p>
                                
                                <div>
                                    <ul>
                                    <li>Simple Moving Average                   (SMA)</li>
                                    <li>Weighted Moving Average             (WMA)</li>
                                    <li>Exponential Moving Average        (EMA)</li>
                                </ul>
                                </div>
                                
                                <p>
                                    In this video Mr.Hamid how to draw moving average link on our charts and how to earn pips , Mr.Hamid is a Great trader , he doing Forex trading from last 4 year, pleas watch video below. if video is lock then pres like button for unlock the video , after watching video leave your comment below the post of moving average Strategy
                                </p>
                                
                                <h2 class="text-center">
                                    <strong>Moving Average Strategy by Raheel Nawaz</strong>
                                </h2>
                                
                                <div class="text-center">
                                    <iframe width="576" height="315" src="https://www.youtube.com/embed/lKLRH4SD-x8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                
                            </div>
                        </div>

                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>

@include('inc.footer')