@include ('inc/header')
        <!-- Content Area -->

    <div class="wrapper mt-5">
        <div class="container">
          
          <div class="content_area_heading large-heading text-center">
        
            <h1 class="heading_title wow animated fadeInUp">
               <strong>
                   Avaiable Banners
               </strong>
            </h1>
            <div class="heading_border wow animated fadeInUp">
                <span class="one"></span><span class="two"></span><span class="three"></span>
            </div>
        </div>
           
            <div class="row">
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                       <div class="border320x100">
                           <p>
                               320x100
                           </p>
                          
                       </div>
<!--                        <img src="assets/img/banner-add/320x100.png" alt="">-->
                    </div>
                    
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary"> Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="border234x60">
                        <p>234x60</p>
                    </div>
                    
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary"> Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border300x100">
                        <p>300x100</p>
                    </div>
<!--                        <img src="assets/img/banner-add/300x100.png" alt="">-->
                    </div>
                </div>
            </div>
           
            
             <div class="row mt-5">
                <div class="col-md-5">
                    <div>
                        <h3 class="text-primary">Logo Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    
                    <div class="text-center">
                       <div class="border468x60">
                           <p>
                               468x60
                           </p>
                           
                       </div>
<!--                        <img src="assets/img/banner-add/468x60.png" alt="">-->
                    </div>
                </div>
                <div class="col-md-7">
                    <div>
                        <h3 class="text-primary"> Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="border728x90">
                        <p>
                            728x90
                        </p>
                    </div>
                    
                </div>
                
            </div>
            
            
             <div class="row mt-5">
                <div class="col-md-12">
                    <div>
                        <h3 class="text-primary">Header Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    
                    <div class="">
                       <div class="border970x250">
                           <p>
                               970x250
                           </p>
                           
                           <p>This is the custom size upto 920x400 avaialable</p>
                           
                       </div>
<!--                        <img src="assets/img/banner-add/468x60.png" alt="">-->
                    </div>
                </div>
               
                
            </div>
            
             <div class="row mt-5">
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Square Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border300x250">
                        <p>300x250</p>
                    </div>
<!--                        <img src="assets/img/banner-add/300x250.png" alt="">-->
                    </div>
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Rectangle Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border180x150">
                        <p>180x150</p>
                    </div>
<!--                        <img src="assets/img/banner-add/180x150.gif" alt="">-->
                    </div>
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary"> Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border300x125">
                        <p>
                            300x125
                        </p>
                    </div>
<!--                        <img src="assets/img/banner-add/300x125.png" alt="">-->
                    </div>
                </div>
            </div>
            
            <div class="row mt-5">
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Medium Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border240x400">
                        <p>240x400</p>
                    </div>
<!--                        <img src="assets/img/banner-add/240x400.png" alt="">-->
                    </div>
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Vertical Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border120x240">
                        <p>
                            120x240
                        </p>
                    </div>
<!--                        <img src="assets/img/banner-add/120x240.gif" alt="">-->
                    </div>
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary"> Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border300x200">
                        <p>
                            300x200
                        </p>
                    </div>
<!--                        <img src="assets/img/banner-add/300x200.png" alt="">-->
                    </div>
                </div>
            </div>
            
            <div class="row mt-5">
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Slider Area Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border160x600">
                        <p>160x600</p>
                    </div>
<!--                        <img src="assets/img/banner-add/160x600.png" alt="">-->
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Skyper Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border120x600">
                        <p>
                            120x600
                        </p>
                    </div>
<!--                        <img src="assets/img/banner-add/120x600.jpg" alt="" height="400">-->
                    </div>
                </div>
                <div class="col-md-4">
                    <div>
                        <h3 class="text-primary">Half Page Banner</h3>
                    </div>
                    <div>
                        <h5 class="text-danger">Rate:</h5>
                    </div>
                    <div class="text-center">
                    <div class="border300x600">
                        <p>
                            300x600
                        </p>
                    </div>
<!--                        <img src="assets/img/banner-add/300x600.png" alt="" height="400">-->
                    </div>
                </div>
            </div>
           
            
        </div>
    </div>


@include('inc.footer')