@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    <div class="family">
                            <div>
                                <h4>It’s not only Mr.Bean Trading story , It’s your also ……!</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="far fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="far fa-clock"></i> September 2, 2015</li>
                                </ul>
                                <div id="shareLink" align="right"></div>
                            </div>
                            <div class="pt-4">
                                Salam Friends
                                <br>
                                <p>
                                    Yu to ye Photo meiny Fun masti ky liy upload ki hai but it’s not funny it’s your story 😛
                                </p>
                                
                                <p>
                                    gee ha ye 99% Forex Trader ki story hai jin jin logo ny learn kiy bagir he Forex Trading start di the aon sab ny start me Mr.Bean ki tarha step by step loss kya tha, zara nichy photo dikhy and apni story ko yaad kary,
                                mein sab sy request karta ho ky Agar Forex Trading karna chahty ho to pehly es ko full learn karo then es me invest karo ya pehr kisi dost ky paisy invest karwaoo warna loss ki Dastany har roz mujy call kar kar ky log sonaty hai, ye na ho kisi din app ki call be mujy aa jay with same story
                                </p>
                                
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/beam.jpg')}}" class="img-fluid">
                                </div>
                               
                                <p>
                                    <strong>
                                    99% Forex Trader have same story like Mr.Bean story, watch it and think, is it yours also ??? it’s not only funny image, its lesson so Learn first before do Forex Trading and share this story with your friends
                                </strong>
                                </p>
                                
                            </div>
                        </div>
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')