@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    <div class="family">
                                        <div>
                                            <h4>What is Forex and How To Become a Successful Forex Trader (Urdu/hindi)</h4>
                                        </div>
                                        <div class="post_representor">
                                            <ul class="">
                                                <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                                <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                                <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                                <li><i class="fa fa-comments"></i> 10 Comments </li>
                                                <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                                <li><div id="shareLink"></div></li>
                                            </ul>
                                        </div>
                                        
                                        <div class="pt-4">
                                            <p>
                                                So far, we have talked about the Forex market, money management and candlestick signals and Trading strategy in our videos. In this video we will talk about the a plan to become a professional and successful Forex Trader. one thing is you know about the Forex market and trading techniques but to use what you know and make money is another thing.
                                            </p>
                                            <ol>
                                                <h4>
                                                    <li>Decision:-</li>
                                                </h4>
                                                <p>
                                                    Your first step should be making the decision seriously, whether you really want to become a Forex Trader and make money with it or not. It is on your decision that Forex Trading supposed to be you full time work for you in future, or you only want to give Forex Trading a try and see how it works. But if you don’t take it seriously results will not be serious either.
                                                </p>
                                                
                                                <h4>
                                                    <li>Learning :-</li>
                                                </h4>
                                                <p>
                                                    After a serious decision, your next step should be learn about the currency market and currency trading.Exactly what you should have to learn and from where you should learn to become a currency trader?
                                                </p>
                                                
                                                <p>
                                                    i will not recommend You to read e-books or every articles on internet to learn just what is the currency market and where it is. The currency market is a market where we can trade the currencies against each other.
                                                </p>
                                                
                                                <p>
                                                    It is where you can buy and sell currencies against each other easily .
                                                About the currency pairs, they created just for convenience of trader. As trader have to buy currency and pay another currency in against, so currencies are placed in pairs to make it easier. Example, EUR/USD is a currency pair.
                                                </p>
                                                
                                                <p>
                                                    It is where you can buy and sell currencies against each other easily .
                                                About the currency pairs, they created just for convenience of trader. As trader have to buy currency and pay another currency in against, so currencies are placed in pairs to make it easier. Example, EUR/USD is a currency pair.
                                                </p>
                                                
                                                <p>
                                                    Meta Trader is the common but most famous platform for trading. It is user-friendly and it is very useful to analyze the price charts and find the trade setups. Even if your broker is not supporting Meta Trader, you can still use the Meta Trader of any other broker to analyze the price charts, and use your broker’s platform only when you want to take a position.
                                                </p>
                                                
                                                <p>
                                                    Next you need learn about the price chart and how it works. you have to know the different kinds of charts and time frames.
                                                </p>
                                                
                                                <h4>
                                                    You have to learn the following things
                                                </h4>
                                                <ol>
                                                    <li>Technical analysis.
                                                    </li>
                                                    <li>Fundamental analysis.</li>
                                                    <li>Set the stop loss and target orders</li>
                                                    <li>The patterns like head, shoulders, triangle, double bottoms and double top</li>
                                                    <li>To calculate the position size, position risk and reward ratio</li>
                                                    <li>The candlestick signals and patterns</li>
                                                    <li>learning all these basic things from internet can take more then a week or two.</li>
                                                </ol>
                                               
                                                <p>
                                                    After learning these basic things, you have to choose a trading system and start
                                                </p>
                                                <br>
                                                practicing it
                                                <br>
                                                <p>
                                                    Best Forex Trading system is the simplest one. No need to choose complicated trading system.
                                                </p>
                                                
                                                <h4>
                                                    <li>Demo Trading :-</li>
                                                </h4>
                                                <p>
                                                    Your next step should be opening a demo trading account and start practicing on it.
                                                </p>
                                                
                                                <p>
                                                    make sure you demo account size and leverage should be exactly the same as the live account you will have in future. Do not open demo account with $10,000 if your live account will be $1000 account.
                                                </p>
                                                <p>
                                                    
                                                start trading on demo account for 3 months, if you gets success on the first month. Then try it for another one month with new demo account. If your 2nd month is also went positive again open a demo account with same size and try it for 3rd month. If you get constant 3 month success you are ready to rock and roll on the live trading account .
                                                </p>
                                                
                                                <p>
                                                    For getting more confidence you can repeat this steps for another 3 months and judge yourself that whether you have control on your emotions or not , before opening live account. when you got full control you have mastered Forex Trading system and you are ready to go live
                                                </p>
                                                
                                                <div class="text-center">
                                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/forex-vs-stocks-fight.jpg')}}" class="img-fluid">
                                                </div>
                                                <h4>
                                                    <li>Live Trading:-</li>
                                                </h4>
                                               <p>
                                                    When you got success in 3 month demo trading and you are ready to open a live account. Make sure you are opening with the same size as the demo account was having. and you will have to take this live account as an other demo account.
                                               </p>
                                               
                                                <p>
                                                    Make sure you opened this account with the money affordable to lose, otherwise you can have fear of losing money that will not let you act properly.
                                                </p>
                                                
                                                <p>
                                                    You should trade on this Live account just like you trading on a demo account, without any fear or tension.
                                                </p>
                                                <p>
                                                    Repeat your live trading success for 3 straight months. Prove to yourself that you can accurately follow your trading system without any facing any problem.
                                                </p>
                                                
                                                
                                                <p>
                                                    You become a Real Forex Trader when you have trust and confidence in your heart.you can easily make money every month when you reach this point.
                                                </p>
                                                <p>
                                                    After you reaching to this point successfully, just stick to your trading system and you Plan to keep making money, Don’t get sidetracked by anything. When you make money with your Forex Trading system, you should stick to it and don’t changed it. if you do so you will lose you money .
                                                </p>
                                            </ol>
                                            <br>
                                            <h5 class="text-center">
                                                Watch Video about How To Become a Successful Forex Trader (Urdu/hindi)
                                            </h5>
                                            
                                            <div>
                                                <iframe width="100%" height="315" src="https://www.youtube.com/embed/6FokO8ntMvo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                            </div>
                                            
                                        </div>
                                    </div>
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>

@include('inc.footer')