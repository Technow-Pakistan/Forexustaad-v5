@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>How to Choose a Forex Broker webinar ready</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                    <li><div id="shareLink"></div></li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                                <h4 class="text-center">
                                    <strong>
                                        In this webinar you learn how does a Forex “newbie” pick a broker? We are organize this webinar to help you to select a best broker available in the forex market
                                    </strong>
                                </h4>
                                <br>
                                <h5 class="text-center">
                                    You will never got information like this before so pleas watch our video and learn much more about how to choose Broker and what is requirements checked before joining any Forex broker market
                                </h5>
                                <br>
                                <h6 class="text-center">
                                    Register your webinar
                                </h6>
                                <br>
                                <div class="text-center">
                                    <a href="how-to-choose-a-forex-broker-in-urdu-webinar.html"><button type="button" class="btn btn-primary btn-lg">Register your Webinar</button></a>
                                </div>
                                <br>
                                <p>
                                    InshaAllah this is information helped you to find 100% perfect broker for your Forex Trading life time
                                </p>
                                
                                <p>
                                    Noow webinar video is available for watching , How to Choose a Forex Broker in urdu (webinar)
                                </p>
                                
                                <p>
                                    If you want to know all these thing which I describe up , then you must Unlock this video by click on any like button about Forex trading,
                                </p>
                                
                                <p>
                                    I Also share some basic information about Forex trading like what is Ask Price , Bid Price and Spread in this video
                                </p>
                               
                                <p>
                                    If you want you watch video just click on How to Choose a Forex Broker in urdu (webinar) ,You must watch this webinar and also share with you friends , thank you
                                </p>
                                
                            </div>
                        </div>


                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>

