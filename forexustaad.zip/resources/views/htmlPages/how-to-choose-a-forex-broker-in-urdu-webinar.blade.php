@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>How to Choose a Forex Trading Broker in urdu (webinar)</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                </ul>
                            </div>
                            
                            <div class="pt-4">
                                <h4 class="text-center">
                                    Why Choosing Forex Broker is imported ?
                                </h4>
                                
                                <p>
                                    <strong>
                                    To Trade in Forex market you need a broker. there is no way around to choose a perfect broker, the problem is that you can not simple choose any broker to trade with because it can make and break the career of a trader , In this webinar I will help you to pick up your perfect broker, when you looking a broker to trade with, there are very import thing which need to know,
                                </strong>
                                </p>
                                
                                <div>
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/how-to-choose-a-forex-broker-urdu.jpg')}}" class="img-fluid">
                                </div>
                                <br>
                                <h3>
                                    What you Need to Know ?
                                </h3>
                                <div>
                                    <ol>
                                    <li>The broker is regulated.</li>
                                    <li>In which country broker hold to your trading money</li>
                                    <li>You need to know the broker have good plate forum, that is reliable and user friendly</li>
                                    <li>You need to know how much Spread charges and other charges like withdraw and despite fee</li>
                                    <li>How helpful and quit their customer service</li>
                                    <li>About they account  tips offer and leverage offers</li>
                                </ol>
                                </div>
                                
                                <p>
                                    If you want to know all these thing which I describe up , then you must Unlock this video by click on any like button about Forex trading,
                                </p>
                                
                                <p>
                                    I Also share some basic information about Forex trading like what is  Ask Price , Bid Price and Spread in this video ,
                                </p>
                                
                                <h5 class="text-center">
                                    Training Video
                                </h5>
                                
                                <h6 class="text-center">
                                    Just youtube video available at time
                                </h6>
                                <br>
                                <div>
                                    <iframe width="100%" height="315" src="https://www.youtube.com/embed/UC0AhxFpilA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </div>
                                
                            </div>
                        </div>


                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>

@include('inc.footer')
