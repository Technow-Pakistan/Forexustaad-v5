@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                @php
                    if(Session::has('error')){ 
                        $error =Session::get('error');
                    }
                @endphp
                @isset($error)
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="alert alert-danger">{{$error}}</div>
                        @php Session::pull('error') @endphp
                    </div>
                @endisset
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    <div class="family">
                            <div>
                                <h4>My Advance Forex Trading Plan on July 2015</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                </ul>
                            </div>
                            
                           <div class="pt-4">
                              <h3>
                                  In this Video I will show you my Real Trading account, which I started 1st July 2015, set 25% Target and in just 10 days I got my target 🙂
                              </h3>
                              <br>
                              <p>
                                  Yes, My Forex Trading plan is really working 😀 ,  Last 6 month ago I share with you My Forex Trading plan pleas go on my site and watch old video , if you have not seen yet.
                              </p>
                              
                              <p>
                                  I share my Trading plan , my rules , My Method, and my strategies on my old Video but now I proof it. Pleas watch Video and get all information about My Forex Trading plan , you can also Download Indicator which i show you in my this video , thank you
                              </p>
                              
                              
                              
                              <div class="text-center">
                                  <iframe width="560" height="315" src="https://www.youtube.com/embed/jwY4nu1lmJ4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                              </div>
                            
                              <h5>
                                  For more information or any problem feel free to contact us..
                              </h5>
                              <ul>
                                  <strong><li>Contact: Raheel Nawaz Jutt</li></strong>
                                  <strong><li>24/7 Live Support</li></strong>
                                  <strong><li>GTalk: Raheeljutt@gmail.com</li></strong>
                                  <strong><li>Skype: raheel6542380</li></strong>
                                  <strong><li>Cell #:   +92-345-6542380</li></strong>
                                  <strong><li>Follow me on Twitter</li></strong>
                                  <strong><li>Find me on Facebook</li></strong>
                                  <strong><li>Circle me on Google+</li></strong>
                                  <strong><li>Subscribe to me On Youtube</li></strong>
                              </ul>
                              
                            </div>
                        </div>
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')