@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    
                    <div class="family">
                            <div>
                                <h4>Learn Forex Trading in Pakistan | manual support and resistance</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                    <li><div id="shareLink"></div></li>
                                </ul>
                            </div>
                            <div class="pt-4">
                                <p>
                                    Friends learn Forex Trading in Pakistan now very easy because we teach you 100% free at ForexUstaad.com. Today we share with you a Forex Trading strategy worth 250$, also teach you how to draw manual support and resistance line on Forex trading Chart, we also give you indicator for auto draw support and resistance line, so it’s very easy and useful for you. now it’s very easy  draw to support and resistance line on your Forex Trading Chart for market analysis, I think it’s best Tool even I love this tool. I earn many pips from support and resistance. It will batter for you best learn manual first and then use auto indicator for drawing support and resistance lines.Thank you
                                </p>
                                
                                <div class="text-center">
                                    <img src="{{URL::to('/public/assets/assets/img/blog-post/Support-and-Resistance-600x294.jpg')}}" class="img-fluid">
                                </div>
                                
                            </div>
                        </div>

                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')