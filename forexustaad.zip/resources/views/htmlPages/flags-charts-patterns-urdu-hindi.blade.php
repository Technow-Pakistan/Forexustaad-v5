@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    <div class="family">
                            <div>
                                <h4>Learn free Flags charts patterns in Urdu | Hindi</h4>
                            </div>
                            <div class="post_representor">
                                <ul class="">
                                    <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                    <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                    <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                    <li><i class="fa fa-comments"></i> 10 Comments </li>
                                    <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                    <li><div id="shareLink"></div></li>
                                </ul>
                            </div>
                            
                           <div class="pt-4">
                              <h4>
                                  Salam o alaikum all my Dear Traders
                              </h4>
                              
                              <p>
                                  Today I’m going to teach you A free chart pattern which is called flags , It’s most popular and profitable pattern. almost every Good Trader use this pattern for his Forex Trading. so Today I will teach you how to trade with upward flags and downward flags. A flag Pattern is a continuation pattern and work’s very simple
                              </p>
                              
                              <strong>Buy :</strong> <p>
                                  when price close above the flag’s Resistance line.
                              </p>
                              <br>
                              <strong>Sell  :</strong> <p>
                                  when price closes below the flag’s support live
                              </p>
                              
                              <div class="text-center">
                                  <img src="{{URL::to('/public/assets/assets/img/blog-post/flag.gif')}}" class="img-fluid">
                              </div>
                              
                              <p>
                                  If you want make more profit from this pattern then you must learn support and resistance.
                              </p>
                              
                              <p>
                                  In this Video I will also teach you about High and Tight Flag, it’s makes more pips for you. I love this pattern because I earn high profit from this pattern so I suggest you watch this video and make your own rules, last thing pleas try every pattern on demo first then on your real account. This is only one pattern I teach you free, I have to teach you 33 other Chart patterns in my paid Training so join me and learn much more….
                              </p>
                             
                              <p>
                                  Learn free high profit candlestick patterns and make much more money as you can
                              </p>
                              
                              <div class="text-center">
                                  <iframe width="580" height="350" src="https://www.youtube.com/embed/mjuQgtLqtC0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                              </div>
                              
                              <p>
                                  Pleas comment blow, if you have any question or feel free to call me for paid Training. Thank you for watching video pleas share with you friends if you like this Video
                              </p>
                              
                              
                            </div>
                        </div>
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>
@include('inc.footer')