@include ('inc/header')
        <!-- Content Area -->

        <div class="content_area">
    <section class="after_banner_content_area">
        <div class="container">
            <div class="row justify-content-center">
                @php
                    if(Session::has('error')){ 
                        $error =Session::get('error');
                    }
                @endphp
                @isset($error)
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="alert alert-danger">{{$error}}</div>
                        @php Session::pull('error') @endphp
                    </div>
                @endisset
                <div class="col-lg-3 col-md-6 col-sm-12 order-2 order-lg-1">
                    @include('inc.home-left-sidebar')
                </div>
                <div class="col-lg-6 col-md-12 order-1 order-lg-2">
                    <div class="family">
                                        <div>
                                            <h4>ForexUstaad Weekly Lucky Draw</h4>
                                        </div>
                                        <div class="post_representor">
                                            <ul class="">
                                                <li><i class="fa fa-user"></i> Raheel Nawaz</li>
                                                <li><i class="fa fa-clock-o"></i> September 2, 2015</li>
                                                <li><i class="fa fa-folder"></i> Jobs scams, Scams</li>
                                                <li><i class="fa fa-comments"></i> 10 Comments </li>
                                                <li><i class="fa fa-eye"></i> 4,276 Views</li>
                                            </ul>
                                        </div>
                                        
                                        <div>
                                            <div>
                                                <iframe width="100%" height="315" src="https://www.youtube.com/embed/6v6i9Dqc3yM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                            </div>
                                            <p>
                                                Forexustaad Lucky Draws promotion is going to be promoted by Mr Raheel Nawaz on 21/11/2016 as an incentive to encourage the local Forex traders to trade with XM.COM also to know about the only broker
                                            BIG . FAIR . HUMAN
                                            </p>
                                            
                                            <p>
                                                Therefore, Forexustaad is working as a partner with XM.COM with aims to increasing and educating traders with proper complete knowledge.
                                            </p>
                                            
                                            <p>
                                                To participate in the Lucky Draw, traders must fill up the following form with full details of themselves and their XM Trading Accounts. CLICK HERE
                                            </p>
                                            
                                            <div class="text-center">
                                                <img src="{{URL::to('/public/assets/assets/img/blog-post/raheel-nawaz-lucky-.jpg')}}" class="img-fluid ">
                                            </div>
                                            <h4>PRIZES</h4>
                                            <p>
                                                Prizes will be announced on Each week Friday, Saturday and Sunday Every winner will get 50$ Cash balance in their accounts
                                            </p>
                                            <h4 class="text-center">1st Round Starts (21/11/2016)</h4>
                                            <div>
                                                <ul>
                                                <li> 1st Announcement 25/11/2015
                                                </li>
                                                <li> 2nd Announcement 26/11/2016</li>
                                                <li> 3rd Announcement 27/11/2016</li>
                                            </ul>
                                            </div>
                                            <h4 class="text-center">2nd Round Starts (28/11/2016)</h4>
                                            <div>
                                                <ul>
                                                <li> 1st Announcement 02/12/2015
                                                </li>
                                                <li> 2nd Announcement 03/12/2016</li>
                                                <li> 3rd Announcement 04/12/2016</li>
                                            </ul>
                                            </div>
                                            <h4 class="text-center">3rd Round Starts (05/12/2016)</h4>
                                            <div>
                                                <ul>
                                                <li> 1st Announcement 09/12/2015
                                                </li>
                                                <li> 2nd Announcement 10/12/2016</li>
                                                <li> 3rd Announcement 11/12/2016</li>
                                            </ul>
                                            </div>
                                            <h4 class="text-center">4th Round Starts (12/12/2016)</h4>
                                            <div>
                                                <ul>
                                                <li> 1st Announcement 16/12/2015
                                                </li>
                                                <li> 2nd Announcement 17/12/2016</li>
                                                <li> 3rd Announcement 18/12/2016</li>
                                            </ul>
                                            </div>
                                            <h4>WHO CAN PARTICIPATE ?</h4>
                                            <p>
                                                Each trader need to have a minimum balance of $100 in their XM trading Account. They can trade as many entries as they wish to trade but each position must be opened for minimum 5 minutes to qualify for the Lucky Draw Competition
                                            </p>
                                            <h4>HOW TO PARTICIPATE ? </h4>
                                            <p>
                                                Visit our website www.forexustaad.com Click on the FOREXUSTAAD Monthly
                                                LUCKY DRAW > Fill up the Form. CLICK HERE
                                                CONDITIONS FOR PARTICIPATION
                                            </p>
                                            <p>
                                                All the new and previous participant can join again for the Next round even they if they were a winner in the last round. All traders can participate in all lucky draws the requirement is only $100 balance and they will need to trade minimum 1 standard lot (100,000 Units) to qualify for the Lucky Draw.
                                            </p>
                                            <h4 class="text-center">Terms and Conditions</h4>
                                            <div>
                                                <ul>
                                                <li>
                                                    This lucky draw is open to all XM trading Account holders those are under my link except all staff of forexustaad.com and all other related promotional partners.
                                                </li>
                                                <li>
                                                    Participants need to have a minimum balance of $100 in their Account. They can trade as many entries as they wish to trade but each position must be opened for minimum 5 minutes to qualify for the Lucky Draw Competition and minimum 10 participants must qualify to open lucky Draw
                                                </li>
                                                <li>
                                                    Forexustaad.com have the right on the photos of the winners to electronically publish and distribute the photo in any Site including the right to translate and electronically publish on forexustaad.com
                                                </li>
                                                <li>
                                                    All winners will be notified by Facebook and forexustaad.com
                                                </li>
                                                <li>
                                                    Prizes are transferable, Trade able or exchangeable for cash. All prizes can be withdrawable anytime.
                                                </li>
                                                <li>
                                                    This lucky draw runs from (21-11-2016) to (18-12-2016), Every week
                                                </li>
                                                <li>
                                                    Participants must trade minimum 1 standard lot (100,000 Units) to Qualify for the lucky Draws
                                                </li>
                                            </ul>
                                            </div>
                                            
                                            <h5 class="text-center">
                                                Going to announce 1st winner of Forexustaad lucky draw</h5>
                                            <div class="text-center">
                                                <iframe width="576" height="315" src="https://www.youtube.com/embed/IsXQ7srxT1I" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                            </div>
                                            <br>
                                            <h5 class="text-center">
                                                Going to announce 2nd winner of Forexustaad lucky draw</h5>
                                            <div class="mt-3 text-center">
                                                <iframe width="576" height="315" src="https://www.youtube.com/embed/1bG9qJtaIoI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                            </div>
                                            <br>
                                            <h5 class="text-center">
                                                Going to announce 3rd winner of Forexustaad lucky draw</h5>
                                            <div class="mt-3 text-center">
                                                <iframe width="576" height="315" src="https://www.youtube.com/embed/vOWW2n8G35M" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                            </div>
                                            
                                        </div>
                                    </div>
                </div>
                               
               
                <div class="col-lg-3 col-md-6 col-sm-12 order-3 order-lg-3">
                    @include('inc.home-right-sidebar')
                </div>
            </div>
        </div>
    </section>
     
<!--     <div id="particles-js" style="height: 0;"></div> -->
</div>


@include('inc.footer')