<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActiveOnSiteModel extends Model
{
    protected $table = "active_on_site";
}
