<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AllCountriesModel extends Model
{
    protected $table="countries";
}
