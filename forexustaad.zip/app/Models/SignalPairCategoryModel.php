<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SignalPairCategoryModel extends Model
{
    protected $table = "signal_pairs_category";
    protected $fillable = ["category"];
}
