<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BrokerCompanyInformationModel;
use App\Models\BrokerCommissionsFeesModel;
use App\Models\BrokerDepositModel;
use App\Models\BrokerAccountInfoModel;
use App\Models\BrokerTradableAssetsModel;
use App\Models\BrokerTradingPlatformModel;
use App\Models\BrokerTradingFeaturesModel;
use App\Models\BrokerCustomerServicesModel;
use App\Models\BrokerReserchEducationModel;
use App\Models\BrokerPromotionModel;
use App\Models\BrokerReviewModel;
use App\Models\BrokerNewsModel;
use App\Models\BorkerPromotionsModel;
use App\Models\TrashModel;

class BorkerController extends Controller
{
    public function Index(Request $request,$id){
        if ($id == 6) {
            $userID = $request->session()->get('admin');
            $broker = BrokerCompanyInformationModel::orderBy('id','asc')->where('Trash',0)->where('userId',$userID->id)->get();
            return view('admin.all-broker',compact('broker'));
        }
        $broker = BrokerCompanyInformationModel::orderBy('id','asc')->where('Trash',0)->get();
        return view('admin.all-broker',compact('broker'));
    }
    public function delete(Request $request, $id){
        $Trash = TrashModel::where('deleteId',$id)->where('category',"Broker")->first();
        $Trash->delete();
        $broker = BrokerCompanyInformationModel::find($id);
        $broker->delete();
        $broker = BrokerCommissionsFeesModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerDepositModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerAccountInfoModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerTradableAssetsModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerTradingPlatformModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerTradingFeaturesModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerCustomerServicesModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerReserchEducationModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $broker = BrokerPromotionModel::where('brokerId',$id)->first();
        if ($broker != null) {
            $broker->delete();
        }
        $brokerReview = BrokerReviewModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerReview) ; $i++) { 
            $review = BrokerReviewModel::where('brokerId',$id)->first();
            if ($review != null) {
                $review->delete();
            }
        }
        $brokerNews = BrokerNewsModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerNews) ; $i++) { 
            $news = BrokerNewsModel::where('brokerId',$id)->first();
            if ($news != null) {
                $news->delete();
            }
        }
        $brokerPromotion = BorkerPromotionsModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerPromotion) ; $i++) { 
            $promotion = BorkerPromotionsModel::where('brokerId',$id)->first();
            if ($promotion != null) {
                $promotion->delete();
            }
        }
        return back();
    }
    public function edit(Request $request, $id){
        $broker1 = BrokerCompanyInformationModel::find($id);
        $broker2 = BrokerDepositModel::where('brokerId',$id)->first();
        $broker3 = BrokerCommissionsFeesModel::where('brokerId',$id)->first();
        $broker4 = BrokerAccountInfoModel::where('brokerId',$id)->first();
        $broker5 = BrokerTradableAssetsModel::where('brokerId',$id)->first();
        $broker6 = BrokerTradingPlatformModel::where('brokerId',$id)->first();
        $broker7 = BrokerTradingFeaturesModel::where('brokerId',$id)->first();
        $broker8 = BrokerCustomerServicesModel::where('brokerId',$id)->first();
        $broker9 = BrokerReserchEducationModel::where('brokerId',$id)->first();
        $broker = BrokerPromotionModel::where('brokerId',$id)->first();
        return view('admin.edit-broker',compact('broker1','broker2','broker3','broker4','broker5','broker6','broker7','broker8','broker9','broker','id'));
    }
    public function editBrokerCompanyInformation(Request $request, $id){
        $data = $request->all();
        if ($request->file("file_photo") != null) {
            $path = $request->file("file_photo")->store("BrokerImages");
            $companyImage = $path;
            $data["image"] = $companyImage;
        }
        if ($request->neverEnd == 1) {
            $data["start"] = null;
            $data["end"] = null;
        }else {
            $data["neverEnd"] = 0;
        }
        $broker1 = BrokerCompanyInformationModel::find($id);
        $broker1->fill($data);
        $broker1->save();
        return back();
    }
    public function Detail(Request $request, $id){
        $broker1 = BrokerCompanyInformationModel::find($id);
        $broker2 = BrokerDepositModel::where('brokerId',$id)->first();
        $broker3 = BrokerCommissionsFeesModel::where('brokerId',$id)->first();
        $broker4 = BrokerAccountInfoModel::where('brokerId',$id)->first();
        $broker5 = BrokerTradableAssetsModel::where('brokerId',$id)->first();
        $broker6 = BrokerTradingPlatformModel::where('brokerId',$id)->first();
        $broker7 = BrokerTradingFeaturesModel::where('brokerId',$id)->first();
        $broker8 = BrokerCustomerServicesModel::where('brokerId',$id)->first();
        $broker9 = BrokerReserchEducationModel::where('brokerId',$id)->first();
        $broker = BrokerPromotionModel::where('brokerId',$id)->first();
        return view('admin.view-broker',compact('id','broker1','broker2','broker3','broker4','broker5','broker6','broker7','broker8','broker9','broker','id'));
    }
    public function Trash(Request $request, $id){
        $user = $request->session()->get("admin");
        $data = BrokerCompanyInformationModel::find($id);
        $data->trash = 1;
        $data->save();
        $brokerNews = BrokerNewsModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerNews) ; $i++) { 
            $news = BrokerNewsModel::where('brokerId',$id)->first();
            if ($news != null) {
                $news->trash = 1;
                $news->save();
            }
        }
        $brokerPromotion = BorkerPromotionsModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerPromotion) ; $i++) { 
            $promotion = BorkerPromotionsModel::where('brokerId',$id)->first();
            if ($promotion != null) {
                $promotion->trash = 1;
                $promotion->save();
            }
        }
        $Trash = new TrashModel;
        $Trash->adminTableId = $user->id;
        $Trash->trashItem = "broker";
        $Trash->category = "Broker";
        $Trash->deleteId = $id;
        $Trash->deleteTitle = $data->title;
        $Trash->save();
        return back();
    }
    public function TrashRestore(Request $request, $id){
        $data = BrokerCompanyInformationModel::find($id);
        $data->trash = 0;
        $data->save();
        $brokerNews = BrokerNewsModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerNews) ; $i++) { 
            $news = BrokerNewsModel::where('brokerId',$id)->first();
            if ($news != null) {
                $news->trash = 0;
                $news->save();
            }
        }
        $brokerPromotion = BorkerPromotionsModel::where('brokerId',$id)->get();
        for ($i=0; $i < count($brokerPromotion) ; $i++) { 
            $promotion = BorkerPromotionsModel::where('brokerId',$id)->first();
            if ($promotion != null) {
                $promotion->trash = 0;
                $promotion->save();
            }
        }
        $Trash = TrashModel::where('deleteId',$id)->where('category',"Broker")->first();
        $Trash->delete();
        return back();
    }
}
